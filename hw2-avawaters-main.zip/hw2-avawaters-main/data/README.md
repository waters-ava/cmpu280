# Homework 2 Data

This folder contains data scraped from OpenSecrets.org.
